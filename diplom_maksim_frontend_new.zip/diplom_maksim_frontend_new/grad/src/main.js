import Vue from "vue";
import App from "./App.vue";
import axios from "axios";
import VueAxios from "vue-axios";
import VueTheMask from "vue-the-mask";
// import AxiosMockAdapter from "axios-mock-adapter";

// const mockAdapter = new AxiosMockAdapter(axios);
// mockAdapter.onPost("http://localhost:8000/schedule/data").reply(200, {
//   data: "Imitated response",
// });

Vue.config.productionTip = false;
Vue.use(VueAxios, axios);
Vue.use(VueTheMask);

new Vue({
  render: (h) => h(App),
}).$mount("#app");
