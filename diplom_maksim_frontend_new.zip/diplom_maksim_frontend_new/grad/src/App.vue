<template>
  <div id="app">
    <section class="loading wrap">
      <h2 class="glob__title">Выберете способ загрузки матрицы</h2>
      <form class="glob-tabs" name="loading-tabs">
        <div
          class="glob-tabs__item"
          :class="{ active: loadActiveTab === 0 }"
          @click="(loadActiveTab = 0), (loadingMethods = 'file'), clearInput()"
        >
          <input
            type="radio"
            name="loading-tabs"
            id="loading-tabs--download"
            class="glob-tabs__item-radio"
            checked
          />
          <label for="loading-tabs--download" class="glob-tabs__item-text"
            >Загрузить матрицу файлом
          </label>
        </div>
        <div
          class="glob-tabs__item"
          :class="{ active: loadActiveTab === 1 }"
          @click="
            (loadActiveTab = 1), (loadingMethods = 'random'), clearInput()
          "
        >
          <input
            type="radio"
            name="loading-tabs"
            id="loading-tabs--generate"
            class="glob-tabs__item-radio"
          />
          <label for="loading-tabs--generate" class="glob-tabs__item-text"
            >Сгенерировать случайную матрицу</label
          >
        </div>
        <div
          class="glob-tabs__item"
          :class="{ active: loadActiveTab === 2 }"
          @click="
            (loadActiveTab = 2), (loadingMethods = 'manual'), clearInput()
          "
        >
          <input
            type="radio"
            name="loading-tabs"
            id="loading-tabs--manually"
            class="glob-tabs__item-radio"
          />
          <label for="loading-tabs--manually" class="glob-tabs__item-text"
            >Ввести матрицу вручную</label
          >
        </div>
      </form>
      <div class="loading-methods">
        <form
          class="loading-methods__form loading-methods__form--load active"
          v-show="loadActiveTab === 0"
          name="methods-loading"
          id="methods_loading"
        >
          <div class="loading-methods__title">Прикрепить файл</div>
          <input
            type="file"
            id="loading-methods--file"
            @change="handleFileChange"
          />
        </form>
        <form
          class="loading-methods__form loading-methods__form--generation"
          v-show="loadActiveTab === 1"
          name="methods-generation"
        >
          <div class="loading-methods__generation-wrap">
            <div class="loading-methods__generation-options">
              <div class="loading-methods__generation-input glob__input">
                <label for="methods-generation-str"
                  >Введите количество строк в матрице</label
                >
                <the-mask
                  mask="XXXXXX"
                  :masked="true"
                  :tokens="phoneRegular"
                  name="methods-generation-str"
                  type="text"
                  v-model="generationRows"
                  required
                />
              </div>
              <div class="loading-methods__generation-input glob__input">
                <label for="methods-generation-col"
                  >Введите количество столбцов в матрице</label
                >
                <the-mask
                  mask="XXXXXX"
                  :masked="true"
                  :tokens="phoneRegular"
                  name="methods-generation-col"
                  type="text"
                  v-model="generationColumns"
                  required
                />
              </div>
              <div class="loading-methods__generation-input glob__input">
                <label for="methods-generation-from"
                  >Введите диапазон генерации от
                </label>
                <the-mask
                  mask="XXXXXX"
                  :masked="true"
                  :tokens="phoneRegular"
                  name="methods-generation-from"
                  type="text"
                  v-model="generationMinValue"
                  required
                />
              </div>
              <div class="loading-methods__generation-input glob__input">
                <label for="methods-generation-before"
                  >Введите диапазон генерации до</label
                >
                <the-mask
                  mask="XXXXXX"
                  :masked="true"
                  :tokens="phoneRegular"
                  name="methods-generation-before"
                  type="text"
                  v-model="generationMaxValue"
                  required
                />
              </div>
            </div>
            <div class="loading-methods__generation-infinity">
              <div class="glob-tabs__item" style="margin-bottom: 25px">
                <input
                  type="checkbox"
                  name="loading-tabs--infinity"
                  id="loading-tabs--infinity"
                  class="glob-tabs__item-radio"
                />
                <label
                  for="loading-tabs--infinity"
                  class="glob-tabs__item-text"
                  @click="infinityInput = !infinityInput"
                  >Добавить бесконечности
                </label>
              </div>
              <div
                class="loading-methods__generation-input glob__input"
                v-show="infinityInput === true"
              >
                <label for="methods-generation-str"
                  >Введите количество бесконечностей</label
                >
                <the-mask
                  mask="XXXXXX"
                  :masked="true"
                  :tokens="phoneRegular"
                  name="methods-generation-str"
                  type="text"
                  v-model="generationInfinity"
                  required
                />
              </div>
            </div>
          </div>

          <button
            type="button"
            class="glob__btn"
            @click="CheckRendMatrix"
            v-bind:data-content="dynamicContent"
          >
            Сгенерировать
          </button>
          <div
            class="loading-methods__generation-wrap"
            v-show="generationMethod === true"
          >
            <div
              v-if="generationMatrix"
              class="loading-methods__generation-table"
            >
              <div
                v-for="(row, rowIndex) in generationMatrix"
                :key="rowIndex"
                class="loading-methods__generation-row"
              >
                <div
                  v-for="(value, colIndex) in row"
                  :key="colIndex"
                  class="loading-methods__generation-item"
                >
                  {{ value }}
                </div>
              </div>
            </div>
          </div>
        </form>
        <form
          class="loading-methods__form loading-methods__form--manual"
          v-show="loadActiveTab === 2"
          name="methods-manual"
        >
          <div class="loading-methods__manual glob__input">
            <label for="loading-methods__manual-row"
              >Введите количество строк в матрице</label
            >
            <the-mask
              type="text"
              name="loading-methods__manual-row"
              v-model="rows"
              mask="XXXXXX"
              :masked="true"
              :tokens="phoneRegular"
              required
            />
          </div>
          <div class="loading-methods__manual glob__input">
            <label for="loading-methods__manual-col"
              >Введите количество столбцов в матрице</label
            >
            <the-mask
              type="text"
              name="loading-methods__manual-col"
              v-model="cols"
              mask="XXXXXX"
              :masked="true"
              :tokens="phoneRegular"
              required
            />
          </div>
          <div
            type=""
            class="glob__btn"
            @click="generateGrid"
            v-bind:data-content="dynamicContent"
          >
            Построить матрицу
          </div>
          <div
            class="loading-methods__manual-wrap"
            v-show="monualMethod === true"
          >
            <div v-if="grid" class="loading-methods__manual-table">
              <div
                v-for="(row, rowIndex) in grid"
                :key="rowIndex"
                class="loading-methods__manual-row"
              >
                <div
                  v-for="(col, colIndex) in row"
                  :key="colIndex"
                  class="loading-methods__manual-col"
                >
                  <input
                    type="text"
                    :name="`input_${rowIndex}_${colIndex}`"
                    class="loading-methods__manual-input"
                    :id="`input_${rowIndex}_${colIndex}`"
                    :value="generationMatrix[rowIndex][colIndex]"
                    @input="
                      updateMatrix(rowIndex, colIndex, $event.target.value)
                    "
                  />
                </div>
              </div>
            </div>
            <!-- <button class="glob__btn">Ввод</button> -->
          </div>
        </form>
      </div>
    </section>
    <section class="algorithm wrap">
      <h2 class="glob__title">
        Выберите модификацию алгоритма “Критического пути”
      </h2>
      <form class="glob-tabs" name="algorithm-tabs">
        <div
          class="glob-tabs__item"
          :class="{ active: modificationActiveTab === 0 }"
          @click="
            (modificationActiveTab = 0), (algorithmMod = 'without_changes')
          "
        >
          <input
            type="radio"
            id="algorithm-tabs--changes"
            name="algorithm-tabs"
            class="glob-tabs__item-radio"
            checked
          />
          <label for="algorithm-tabs--changes" class="glob-tabs__item-text"
            >Распределение без изменений</label
          >
        </div>
        <div
          class="glob-tabs__item"
          :class="{ active: modificationActiveTab === 1 }"
          @click="
            (modificationActiveTab = 1), (algorithmMod = 'inf')
          "
        >
          <input
            type="radio"
            id="algorithm-tabs--inf"
            name="algorithm-tabs"
            class="glob-tabs__item-radio"
          />
          <label for="algorithm-tabs--inf" class="glob-tabs__item-text"
            >С учетом бесконечности</label
          >
        </div>
        <div
          class="glob-tabs__item"
          :class="{ active: modificationActiveTab === 2 }"
          @click="
            (modificationActiveTab = 2),
              (algorithmMod = 'inf_count')
          "
        >
          <input
            type="radio"
            name="algorithm-tabs"
            id="algorithm-tabs--count"
            class="glob-tabs__item-radio"
          />
          <label for="algorithm-tabs--count" class="glob-tabs__item-text"
            >С учетом количества бесконечностей в строке</label
          >
        </div>
      </form>
      <div class="algorithm__title">Описание модификации</div>
      <div class="algorithm__textblock">
        <div class="algorithm__text" v-show="modificationActiveTab === 0">
          Далеко-далеко за словесными горами в стране, гласных и согласных живут
          рыбные тексты.
        </div>
        <div class="algorithm__text" v-show="modificationActiveTab === 1">
          Далеко-далеко за, словесными горами в стране гласных и согласных живут
          рыбные.
        </div>
        <div class="algorithm__text" v-show="modificationActiveTab === 2">
          Далеко-далеко за словесными горами в стране гласных и согласных живут
          рыбные тексты. Прямо правилами одна составитель рукопись!
        </div>
      </div>
    </section>
    <section class="algorithm wrap">
      <h2 class="glob__title">Выбирете критерий модификации алгоритма</h2>
      <form class="glob-tabs" name="algorithm-tabs">
        <div
          class="glob-tabs__item"
          :class="{ active: algorithmActiveTab === 0 }"
          @click="(algorithmActiveTab = 0), (solutionMethod = 'minimax')"
        >
          <input
            type="radio"
            id="algorithm-tabs--min"
            name="algorithm-tabs"
            class="glob-tabs__item-radio"
            checked
          />
          <label for="algorithm-tabs--min" class="glob-tabs__item-text"
            >Минимаксный критерий</label
          >
        </div>
        <div
          class="glob-tabs__item"
          :class="{ active: algorithmActiveTab === 1 }"
          @click="(algorithmActiveTab = 1), (solutionMethod = 'square')"
        >
          <input
            type="radio"
            id="algorithm-tabs--square"
            name="algorithm-tabs"
            class="glob-tabs__item-radio"
          />
          <label for="algorithm-tabs--square" class="glob-tabs__item-text"
            >Квадратичный критерий</label
          >
        </div>
        <div
          class="glob-tabs__item"
          :class="{ active: algorithmActiveTab === 2 }"
          @click="(algorithmActiveTab = 2), (solutionMethod = 'cubic')"
        >
          <input
            type="radio"
            name="algorithm-tabs"
            id="algorithm-tabs--cube"
            class="glob-tabs__item-radio"
          />
          <label for="algorithm-tabs--cube" class="glob-tabs__item-text"
            >Кубический критерий</label
          >
        </div>
      </form>
      <div class="algorithm__title">Описание метода</div>
      <div class="algorithm__textblock">
        <div class="algorithm__text" v-show="algorithmActiveTab === 0">
          Алгоритм Плотникова-Зверева - это метод выбора оптимальной стратегии в
          условиях неопределенности, основанный на минимаксном критерии.
        </div>
        <div class="algorithm__text" v-show="algorithmActiveTab === 1">
          Алгоритм Плотникова-Зверева по квадратичному критерию – это алгоритм
          оптимизации функции, который использует квадратичный критерий для
          оценки качества решения.
        </div>
        <div class="algorithm__text" v-show="algorithmActiveTab === 2">
          Алгоритм Плотникова-Зверева по кубическому критерию – это алгоритм
          выбора признаков в задаче регрессии, который основан на методе
          наименьших квадратов и регуляризации Лассо.
        </div>
      </div>
      <button
        class="glob__btn"
        @click="checkingFields"
        v-bind:data-content="dynamicContent"
        :class="{ checkingFields: btnGen === true }"
      >
        Сгенерировать
      </button>
    </section>
    <section class="result wrap">
      <div class="result-out">
        <div v-if="answer" class="result-out__generation-table">
          <div
            v-for="(row, rowIndex) in answer"
            :key="rowIndex"
            class="result-out__generation-row"
          >
            <div
              v-for="(value, colIndex) in row"
              :key="colIndex"
              class="result-out__generation-item"
            >
              {{ value }}
            </div>
          </div>
        </div>
      </div>
      <button class="glob__btn" @click="downloadResult">Скачать результат</button>
    </section>
  </div>
</template>

<script>
import axios from "axios";
// import MockAdapter from "axios-mock-adapter";

export default {
  name: "App",
  data() {
    return {
      loadActiveTab: 0,
      algorithmActiveTab: 0,
      modificationActiveTab: 0,
      monualMethod: false,
      generationMethod: false,
      btnGen: false,
      rows: null,
      cols: null,
      grid: null,
      inputValue: "",
      // matrix: [],

      dynamicContent: "заполните все поля",
      phoneRegular: {
        X: {
          pattern: /\d/,
        },
      },

      // отправка
      apiUrl: "http://localhost:8000",

      // метод отправки матрицы
      loadingMethods: "file",

      // метод решения
      solutionMethod: "minimax",

      // модификация алгоритма
      algorithmMod: "without_changes",

      // параметры случайной генирации
      generationRows: null,
      generationColumns: null,
      generationMinValue: null,
      generationMaxValue: null,
      generationInfinity: null,
      infinityInput: false,

      // фаил
      file: null,

      //  матрица
      generationMatrix: null,

      // ответ
      answer: null,
      id: null
    };
  },
  methods: {
    // генерация руной матрицы
    generateGrid(e) {
      const hasValues = this.rows !== null && this.cols !== null;
      if (hasValues) {
        this.msgBtn(e.target);
        this.generationMatrix = [];
        this.monualMethod = true;
        const rowCount = parseInt(this.rows);
        const colCount = parseInt(this.cols);
        for (let i = 0; i < rowCount; i++) {
          this.generationMatrix.push([]);
        }
        this.grid = Array.from({ length: rowCount }, (_, rowIndex) =>
          Array.from({ length: colCount }, (_, colIndex) => ({
            name: `input_${rowIndex}_${colIndex}`,
          }))
        );
      } else {
        this.msgBtn(e.target, "Заполните все поля");
      }
    },

    // фаил
    handleFileChange(event) {
      this.file = event.target.files[0];
    },

    //  проверка
    checkingFields(e) {
      switch (this.loadingMethods) {
        case "file":
          if (this.file === null) {
            this.msgBtn(e.target, "заполните все поля");
          } else {
            this.sendRequest();
            this.msgBtn(e.target);
          }
          break;

        case "random":
          if (
            this.generationRows === null ||
            this.generationColumns === null ||
            this.generationMinValue === null ||
            this.generationMaxValue === null
          ) {
            this.msgBtn(e.target, "сначала необходимо сгенерировать матрицу");
          } else {
            this.sendRequest();
            this.msgBtn(e.target);
          }
          break;

        case "manual":
          if (this.generationMatrix === null) {
            this.msgBtn(e.target, "заполните все поля");
          } else {
            this.sendRequest();
            this.msgBtn(e.target);
          }
          break;
      }
    },

    // отчистка
    clearInput() {
      this.dynamicContent = "";
      document.querySelector('[name="methods-loading"]').reset();
      document.querySelector('[name="methods-generation"]').reset();
      document.querySelector('[name="methods-manual"]').reset();
      this.generationRows = null;
      this.generationColumns = null;
      this.generationMinValue = null;
      this.generationMaxValue = null;
      this.generationMatrix = null;
      this.generationInfinity = null;
      this.infinityInput = false;

      this.rows = null;
      this.cols = null;
      this.grid = null;

      this.file = null;
    },

    // строки в числа
    updateMatrix(rowIndex, colIndex, value) {
      if (/^(inf|\d+)$/.test(value)) {
        this.generationMatrix[rowIndex][colIndex] = parseInt(value);
      } else {
        document.getElementById(`input_${rowIndex}_${colIndex}`).value = "inf";
        value = document.getElementById(`input_${rowIndex}_${colIndex}`).value;
        console.log(rowIndex, colIndex, value);
      }
      if (value === "inf") {
        this.generationMatrix[rowIndex][colIndex] = value;
      }
    },

    // msg у кнопки
    msgBtn(trget, msg) {
      let btnIndex = trget;
      if (msg) {
        btnIndex.classList.add("checkingFields");
        this.dynamicContent = msg;
      } else {
        btnIndex.classList.remove("checkingFields");
      }
    },

    // проверка гет запроса
    CheckRendMatrix(e) {
      const hasValues =
        this.generationRows !== null &&
        this.generationColumns !== null &&
        this.generationMinValue !== null &&
        this.generationMaxValue !== null;

      if (this.infinityInput === false) {
        if (hasValues) {
          this.rendMatrix();
          this.msgBtn(e.target);
        } else {
          this.msgBtn(e.target, "Заполните все поля");
        }
      } else {
        if (hasValues & (this.generationInfinity !== null)) {
          let sumValue = this.generationColumns * this.generationRows;
          if (sumValue < this.generationInfinity) {
            this.msgBtn(
              e.target,
              "Kоличество бесконечностей превышает количество ячеек матрицы"
            );
          } else {
            this.rendMatrix();
            this.msgBtn(e.target);
          }
        } else {
          this.msgBtn(e.target, "Введите количество бесконечностей");
        }
      }
    },

    // гет запрос на генирацию матрицы
    rendMatrix() {
      // _____________!!!мок!!!______________________
      // // Создаем экземпляр axios-mock-adapter
      // const mock = new MockAdapter(axios);

      // // Устанавливаем моковый ответ для POST-запроса на apiUrl
      // mock.onGet(`${this.apiUrl}/matrix`).reply(200, {
      //   matrix: [
      //     [3, 73, "inf", 81],
      //     [50, 49, 80, 59],
      //     [60, "inf", 46, "inf"],
      //   ],
      // });
      // _____________!!!мок!!!______________________
      this.generationMatrix = [];
      axios
        .get(`${this.apiUrl}/matrix`, {
          params: {
            n: this.generationRows,
            m: this.generationColumns,
            min: this.generationMinValue,
            max: this.generationMaxValue,
            inf_count: this.generationInfinity,
          },
          headers: {
            "Access-Control-Allow-Origin": "localhost:8000",
            "Content-Type": "application/json",
            "Cache-Control": "no-cache, no-store, must-revalidate",
            Pragma: "no-cache",
            Expires: "0",
          },
        })
        .then((response) => {
          this.generationMethod = true;
          this.generationMatrix = response.data.matrix;
        })
        .catch((error) => {
          // Обработка ошибки
          console.log(error);
        });
    },

    // пост запрос на генерацию ответа
    sendRequest() {
      // _____________!!!мок!!!______________________
      // Создаем экземпляр axios-mock-adapter
      // const mock = new MockAdapter(axios);

      // // Устанавливаем моковый ответ для POST-запроса на apiUrl
      // mock.onPost(`${this.apiUrl}/schedule`).reply(200, {
      //   solution: [
      //     ["p0", "p1", "p2"],
      //     ["9", "14", "14"],
      //     ["6", "", "9"],
      //     ["15", "14", "23"],
      //   ],
      // });
      // _____________!!!мок!!!______________________

      const formData = new FormData();
      formData.append("algorithm", this.solutionMethod);
      formData.append("inf_algorithm", this.algorithmMod);
      formData.append("file", this.file);
      formData.append("matrix", JSON.stringify(this.generationMatrix));

      for (const entry of formData.entries()) {
        console.log(entry);
      }
      axios
        .post(`${this.apiUrl}/schedule/`, formData, {
          headers: {
            "Access-Control-Allow-Origin": "localhost:8000",
            "Content-Type": "multipart/form-data",
          },
        })
        .then((response) => {
          // Обработка ответа
          this.answer = response.data.solution;
          this.id = response.data.id;
        })
        .catch((error) => {
          // Обработка ошибки
          console.error(error);
        });
    },

    downloadResult() {
      if (this.id == null){
        return
      }

      axios
        .get(`${this.apiUrl}/download_schedule/`, {
          params: {
            id: this.id,
          },
          headers: {
            "Access-Control-Allow-Origin": "localhost:8000",
            "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          },
          responseType: 'blob'
        })
        .then(response => {
          const contentDisposition = response.headers['content-disposition'];
          const fileName = contentDisposition ? contentDisposition.split('filename=')[1] || 'matrix.xlsx' : 'matrix.xlsx';

          const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

          // Сохранение файла на клиенте
          if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            // Для IE
            window.navigator.msSaveOrOpenBlob(blob, fileName);
          } else {
            // Для других браузеров
            const downloadLink = document.createElement('a');
            const url = window.URL.createObjectURL(blob);
            downloadLink.href = url;
            downloadLink.download = fileName;
            downloadLink.click();
            window.URL.revokeObjectURL(url);
          }
        }).catch(error => {
          console.error(error);
        });
    },
  },
};
</script>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
*,
*::before,
*::after {
  box-sizing: border-box;
}

/* Remove default margin */
body,
h1,
h2,
h3,
h4,
p,
figure,
blockquote,
dl,
dd {
  margin: 0;
}

/* Remove list styles on ul, ol elements with a list role, which suggests default styling will be removed */
ul[role="list"],
ol[role="list"] {
  list-style: none;
}

/* Set core root defaults */
html:focus-within {
  scroll-behavior: smooth;
}

/* Set core body defaults */
body {
  min-height: 100vh;
  margin-bottom: 50px;
  text-rendering: optimizeSpeed;
  box-sizing: border-box;
  /* line-height: 1.5; */
}

/* A elements that don't have a class get default styles */
a:not([class]) {
  text-decoration-skip-ink: auto;
}

/* Make images easier to work with */
img,
picture {
  max-width: 100%;
  display: block;
}

/* Inherit fonts for inputs and buttons */
input,
button,
textarea,
select {
  font: inherit;
}

/* Remove all animations and transitions for people that prefer not to see them */
@media (prefers-reduced-motion: reduce) {
  html:focus-within {
    scroll-behavior: auto;
  }
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}

.checkingFields {
  position: relative;
  &::after {
    content: attr(data-content);
    position: absolute;
    width: max-content;
    top: 0;
    transform: translateY(50%);
    left: 110%;
    color: #ba0808;
  }
}

.wrap {
  max-width: 1480px;
  width: 100%;
  margin: 0 auto;
  padding: 0 15px;
}

.glob {
  &__title {
    font-weight: 700;
    font-size: 24px;
    line-height: 29px;
    letter-spacing: -0.017em;
    color: #000000;
    text-align: left;

    margin-bottom: 30px;
  }
  &__btn {
    width: 221px;
    font-weight: 700;
    font-size: 16px;
    line-height: 19px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    letter-spacing: -0.017em;
    color: #ffffff;

    border: 0;
    padding: 11px 26px;
    background: #ba0808;
    border-radius: 10px;
    transition: 0.35s ease-in-out;
    box-shadow: 0 0 12px 1px #2c3e5094;
    margin-top: 35px;
    cursor: pointer;
    &:hover {
      background: #ffffff;
      color: #ba0808;
    }
  }
  &-tabs {
    display: flex;
    align-items: center;
    margin-bottom: 25px;
    &__item {
      margin-right: 25px;
      display: flex;
      align-items: center;
      cursor: pointer;
      & input {
        display: none;
        &:checked + label {
          &:after {
            opacity: 1;
          }
        }
      }
      & label {
        display: flex;
        align-items: center;
        position: relative;
        cursor: pointer;
        &:before {
          content: " ";
          width: 22px;
          height: 22px;
          background: #d9d9d9;
          border-radius: 50%;
          margin-right: 7px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        &:after {
          content: " ";
          position: absolute;
          top: 6px;
          left: 6px;
          border-radius: 50%;
          width: 10px;
          height: 10px;
          background: #000000;
          opacity: 0;
          transition: 0.25s ease-in-out;
        }
      }
    }
  }
  &__input {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 22px;
    &:last-of-type {
      margin-bottom: 0;
    }
    & label {
      font-weight: 400;
      font-size: 15px;
      line-height: 12px;
      letter-spacing: -0.017em;
      color: #000000;
      margin-bottom: 6px;
    }
    & input {
      max-width: 221px;
      width: 100%;
      padding: 5px 10px;
      background: #edebeb;
      border-radius: 5px;
      border: 0;
      outline: 0;
    }
  }
}
.loading {
  margin-bottom: 15px;
  &-methods {
    &__form {
      &--load {
        background: #edebeb;
        border-radius: 10px;
        width: fit-content;
        height: 102px;
        padding: 5px 40px;
      }
    }
    &__title {
      font-weight: 400;
      font-size: 16px;
      line-height: 19px;
      letter-spacing: -0.017em;
      color: #000000;
      margin-bottom: 25px;
    }
    &__manual {
      &-table {
        margin-top: 35px;
        max-width: 100%;
        overflow: auto;
      }
      &-row {
        margin-bottom: 5px;
        display: flex;
        flex-wrap: nowrap;
        &:last-child {
          margin-bottom: 0;
        }
      }
      &-input {
        background: #edebeb;
        padding: 5px;
        border-radius: 3px;
        width: 40px;
        height: 25px;
        border: 0;
        outline: none;
        margin-right: 5px;
        text-align: center;
      }
    }
    &__generation {
      &-wrap {
        display: flex;
      }
      &-infinity {
        margin-left: 40px;
      }
      &-table {
        margin-top: 15px;
        max-width: 100%;
        overflow: auto;
      }
      &-row {
        margin-bottom: 5px;
        display: flex;
        flex-wrap: nowrap;
        &:last-child {
          margin-bottom: 0;
        }
      }
      &-item {
        background: #edebeb;
        padding: 5px;
        border-radius: 3px;
        width: auto;
        border: 0;
        margin-right: 5px;
        text-align: center;
      }
    }
  }
}
.algorithm {
  &__textblock {
    margin-bottom: 15px;
    background: #edebeb;
    border-radius: 10px;
    max-width: 601px;
    width: 100%;
    padding: 10px 15px;
    text-align: left;
  }
  &__title {
    font-weight: 600;
    font-size: 16px;
    line-height: 19px;
    letter-spacing: -0.017em;
    color: #000000;
    text-align: left;
    margin-bottom: 15px;
  }
  &__text {
    font-weight: 400;
    font-size: 14px;
    line-height: 17px;
    letter-spacing: -0.017em;

    color: #000000;
  }
}
.result {
  margin-top: 30px;
  &-out {
    width: 100%;
    height: 914px;
    overflow: auto;
    background: #d9d9d9;
    border-radius: 10px;
    padding: 20px;
  }
  &-out__generation {
    &-table {
      max-width: 100%;
      overflow: auto;
    }
    &-row {
      margin-bottom: 5px;
      display: flex;
      flex-wrap: nowrap;
      &:last-child {
        margin-bottom: 0;
      }
    }
    &-item {
      background: #ffffff;
      padding: 5px;
      border-radius: 3px;
      width: 50px;
      border: 0;
      margin-right: 5px;
      text-align: center;
      word-wrap: break-word;
    }
  }
}
input[type="number"]::-webkit-outer-spin-button,
input[type="number"]::-webkit-inner-spin-button {
  -webkit-appearance: none; // Yeah, yeah everybody write about it
}

input[type="number"],
input[type="number"]:hover,
input[type="number"]:focus {
  appearance: none;
  -moz-appearance: textfield;
}
</style>
