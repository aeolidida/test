import pandas as pd
import numpy as np
import math

class Algorithm:
    @staticmethod
    def sort_with_inf_algorithm(inf_algorithm):
        if inf_algorithm == "without_changes":
            return lambda item: -np.sum(item, where=np.isfinite(item))
        elif inf_algorithm == "inf":
            return lambda item: (not np.any(item == np.inf), -np.sum(item, where=np.isfinite(item)))
        elif inf_algorithm == "inf_count":
            return lambda item: (-np.count_nonzero(item == np.inf), -np.sum(item, where=np.isfinite(item)))

    @staticmethod
    def cast_to_int(num):
        if num == np.inf:
            return num
        elif np.abs(np.floor(num) - num)< 0.001:
            return int(np.floor(num))
        elif np.abs(np.ceil(num) - num)< 0.001:
            return int(np.ceil(num))
        else:
            return num
    
    @staticmethod
    def make_result_schedule(schedule, n, m):
        max_len = 0

        for i in range(m):
            if max_len < len(schedule[i]):
                max_len = len(schedule[i])

        result = [[] for _ in range(max_len)]

        for i in range(max_len):
            for j in range(m):
                s = ""
                if i < len(schedule[j]):
                    s = str(schedule[j][i])
                result[i].append(s)         

        result.append([str(Algorithm.cast_to_int(np.sum(np.array(schedule[i])))) for i in range(m)])
        result.insert(0, ["p" + str(i+1) for i in range(m)])

        return result

    @staticmethod
    def plotnikov_zverev_minimax(matrix, inf_algorithm):
        n, m = matrix.shape
        
        l = list(matrix)
        sorted_matrix = np.array(sorted(l, key=Algorithm.sort_with_inf_algorithm(inf_algorithm)))

        tmp_matrix = np.zeros((n,m))
        schedule = [[] for _ in range(m)]         
        
        min_el_arg = np.argmin(sorted_matrix[0])
        min_el = sorted_matrix[0][min_el_arg]
        print("min_el_arg "+str(min_el_arg))
        print("min_el " + str(min_el))
        
        tmp_matrix[0][min_el_arg] = min_el
        schedule[min_el_arg].append(Algorithm.cast_to_int(min_el))
        print(tmp_matrix)
        
        for i in range(1, n):
            if np.min(tmp_matrix[i-1])==np.inf:
                break
            
            print("mu")
            print(tmp_matrix[i-1]+sorted_matrix[i])
            min_el_arg = np.argmin(tmp_matrix[i-1]+sorted_matrix[i])
            min_el = sorted_matrix[i][min_el_arg]
            if tmp_matrix[i-1][min_el_arg] == np.inf:
                min_el_arg = np.argmin(tmp_matrix[i-1])
                min_el = sorted_matrix[i][min_el_arg]
            print("min_el_arg "+str(min_el_arg))
            print("min_el "  + str(min_el))
            
            tmp_matrix[i] = tmp_matrix[i-1]
            tmp_matrix[i][min_el_arg] = tmp_matrix[i][min_el_arg] + min_el
            print(tmp_matrix)
            
            schedule[min_el_arg].append(Algorithm.cast_to_int(min_el))
            
        return Algorithm.make_result_schedule(schedule, n, m)

    @staticmethod
    def plotnikov_zverev_square(matrix, inf_algorithm):
        n, m = matrix.shape
        
        l = list(matrix)
        sorted_matrix = np.array(sorted(l, key=Algorithm.sort_with_inf_algorithm(inf_algorithm)))
        print(sorted_matrix)
        
        tmp_matrix = np.zeros((n,m))
        schedule = [[] for _ in range(m)]         
        
        min_el_arg = np.argmin(sorted_matrix[0]**2)
        min_el = sorted_matrix[0][min_el_arg]
        print("min_el_arg "+str(min_el_arg))
        print("min_el " + str(min_el))
        
        tmp_matrix[0][min_el_arg] = min_el
        schedule[min_el_arg].append(Algorithm.cast_to_int(min_el))
        print(tmp_matrix)

        for i in range(1, n):
            if np.min(tmp_matrix[i-1])==np.inf:
                break
            
            mu = [np.sum(tmp_matrix[i-1]**2) + (sorted_matrix[i][j]+tmp_matrix[i-1][j])**2 - tmp_matrix[i-1][j]**2 for j in range(m)]
            print(mu)

            min_el_arg = np.argmin(mu)
            min_el = sorted_matrix[i][min_el_arg]
            if tmp_matrix[i-1][min_el_arg] == np.inf:
                min_el_arg = np.argmin(tmp_matrix[i-1])
                min_el = sorted_matrix[i][min_el_arg]
            print("min_el_arg "+str(min_el_arg))
            print("min_el"  + str(min_el))
            
            tmp_matrix[i] = tmp_matrix[i-1]
            tmp_matrix[i][min_el_arg] = tmp_matrix[i][min_el_arg] + min_el
            print(tmp_matrix)
            
            schedule[min_el_arg].append(Algorithm.cast_to_int(min_el))
            
        return Algorithm.make_result_schedule(schedule, n, m)

    @staticmethod
    def plotnikov_zverev_cubic(matrix, inf_algorithm):
        n, m = matrix.shape
        
        l = list(matrix)
        sorted_matrix = np.array(sorted(l, key=Algorithm.sort_with_inf_algorithm(inf_algorithm)))

        tmp_matrix = np.zeros((n,m))
        schedule = [[] for _ in range(m)]         
        
        min_el_arg = np.argmin(sorted_matrix[0]**3)
        min_el = sorted_matrix[0][min_el_arg]
        print("min_el_arg "+str(min_el_arg))
        print("min_el " + str(min_el))
        
        tmp_matrix[0][min_el_arg] = min_el
        schedule[min_el_arg].append(Algorithm.cast_to_int(min_el))
        print(tmp_matrix)
        
        for i in range(1, n):
            if np.min(tmp_matrix[i-1])==np.inf:
                break
            
            mu = [np.sum(tmp_matrix[i-1]**3) + (sorted_matrix[i][j]+tmp_matrix[i-1][j])**3 - tmp_matrix[i-1][j]**3 for j in range(m)]
            print(mu)
                    
            min_el_arg = np.argmin(mu)
            min_el = sorted_matrix[i][min_el_arg]
            
            print("min_el_arg "+str(min_el_arg))
            print("min_el " + str(min_el))
            if tmp_matrix[i-1][min_el_arg] == np.inf:
                min_el_arg = np.argmin(tmp_matrix[i-1])
                min_el = sorted_matrix[i][min_el_arg]
            tmp_matrix[i] = tmp_matrix[i-1]
            tmp_matrix[i][min_el_arg] = tmp_matrix[i][min_el_arg] + min_el
            print(tmp_matrix)
            
            schedule[min_el_arg].append(Algorithm.cast_to_int(min_el))
            
        return Algorithm.make_result_schedule(schedule, n, m)

