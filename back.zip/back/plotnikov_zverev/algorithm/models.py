from djongo import models

class Schedule(models.Model):
    id = models.AutoField(primary_key=True)
    algorithm = models.CharField(max_length=50)
    inf_algorithm = models.CharField(max_length=50)
    matrix = models.JSONField()
    result = models.JSONField()

    class Meta:
        db_table = 'schedule'