# urls.py
from django.urls import path
from .views import DownloadScheduleAPIView, MatrixAPIView,ScheduleAPIView 

urlpatterns = [
    path('matrix/', MatrixAPIView.as_view(), name='matrix'),
    path('schedule/', ScheduleAPIView.as_view(), name='schedule'),
    path('download_schedule/', DownloadScheduleAPIView.as_view(), name='download_schedule'),
]