from django.http import FileResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from .algorithm import Algorithm
import pandas as pd
import numpy as np
import math as m
from .models import Schedule
import json
import copy as c
import os
import random

class MatrixAPIView(APIView):
    def get(self, request):
        n = int(request.query_params.get('n', 0))
        m = int(request.query_params.get('m', 0))
        min = int(request.query_params.get('min', 0))
        max = int(request.query_params.get('max', 0))
        inf_count = int(request.query_params.get('inf_count', 0))
        
        if not MatrixAPIView.validate_params(n,m,min,max) or not MatrixAPIView.validate_inf_count(inf_count, n, m):
            return Response({'error': 'Invalid params'}, status=400)

        # Генерация матрицы
        matrix = [[random.randint(min, max-1) for _ in range(m)] for _ in range(n)]

        if inf_count > 0:
            matrix = MatrixAPIView.insert_infinity(matrix, inf_count)
            
        response_data = { 
            'matrix' : matrix 
        }        

        return Response(response_data)

    @staticmethod
    def validate_params(*params):
        for p in params:
            if p <= 0:
                return False
            return True

    @staticmethod
    def validate_inf_count(inf_count, n, m):
        if inf_count <= 0 or inf_count > n*m:
            return False
        return True    

    @staticmethod
    def insert_infinity(matrix_t, inf_count):
        n = len(matrix_t)
        m = len(matrix_t[0])
        matrix = c.deepcopy(matrix_t)
        pos = [[random.randint(0, n-1), random.randint(0, m-1)] for _ in range(inf_count)]   
        for i in range(inf_count):
            if matrix[pos[i][0]][pos[i][1]] == "inf":
                for it in range(len(matrix)):
                    for jt in range(len(matrix[0])):
                        if matrix[it][jt] != "inf":
                            pos[i][0] = it
                            pos[i][1] = jt
            matrix[pos[i][0]][pos[i][1]] = "inf"
        return matrix

class ScheduleAPIView(APIView):
    def post(self, request):
        algorithm = request.data.get('algorithm')
        inf_algorithm = request.data.get('inf_algorithm')
        file = request.data.get('file')
        matrix = request.data.get('matrix')
        matrix = json.loads(matrix)

        if not matrix:
            matrix = ScheduleAPIView.get_matrix_from_file(file)
        else:
            matrix = np.array(ScheduleAPIView.transform_inf_stof(matrix))

        result = None               
        
        if algorithm == 'minimax':
            result = Algorithm.plotnikov_zverev_minimax(matrix, inf_algorithm)
        elif algorithm == 'square':
            result = Algorithm.plotnikov_zverev_square(matrix, inf_algorithm)
        elif algorithm == 'cubic':
            result = Algorithm.plotnikov_zverev_cubic(matrix, inf_algorithm)
        
        # Создание экземпляра модели Schedule
        schedule = Schedule(
            algorithm=algorithm,
            inf_algorithm=inf_algorithm,
            matrix=matrix.tolist(),
            result=result
        )

        # Сохранение экземпляра модели в базе данных
        schedule.save()
        print(schedule.id)
        
        response_data = {
	        'id' : schedule.id,
            'solution': result
        }

        return Response(response_data)
    
    @staticmethod
    def get_matrix_from_file(file):
        try:
            dataframe = pd.read_excel(file)
            matrix = dataframe.to_numpy()
            
            for i in range(len(matrix)):
                for j in range(len(matrix[0])):
                    if matrix[i][j] == "inf":
                        matrix[i][j] = np.inf
            
            return matrix

        except Exception as e:
            print('Ошибка при чтении файла:', str(e))
            return None

    @staticmethod
    def transform_inf_stof(matrix_i):
        matrix = c.deepcopy(matrix_i)
        for i in range(len(matrix)):
            for j in range(len(matrix[0])):
                if matrix[i][j] == "inf":
                    matrix[i][j] = float('inf')
        return matrix


class DownloadScheduleAPIView(APIView):
    def get(self, request):
        
        id = int(request.query_params.get('id'))
        
        schedule = None
        try:
            schedule = Schedule.objects.filter(id=id).first()
        except Schedule.DoesNotExist as e:
            return Response({'error': e}, status=400)

        matrix = schedule.matrix
        df = pd.DataFrame(matrix)
        file_path =  "result.xlsx"
        df.to_excel(file_path, index = False)
        
        response = None
        with open(file_path, 'rb') as file:
            response = FileResponse(file.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            response['Content-Disposition'] = 'attachment; filename=result.xlsx'
        
        os.remove(file_path)
        return response